# 📝 LISTA DE JAVASCRIPT 📝


🔸 Para fazer esses exercícios, **você deve usar o nosso boilerpate**  
🔸 **Não modifiquem o arquivo testes.js**  
🔸 Escreva o código de vocês dentro da **função** correspondente ao número do exercício, no arquivo **exercicios.js**  
🔸 Nos exercícios envolvendo **objeto** lembrem-se de colocar os nomes das propriedades **exatamente** como mostramos nos enunciados.  
🔸 Se você travar em um exercício, pule para o próximo. E, se mesmo assim continuar muito travado/travada, venha falar conosco.  
🔸 Os testes vão começar falando que vocês erraram a questão porque ainda não existe lógica dentro das funções! Não se desespere com isso!  
🔸 Sintam-se livres para consultar os materiais das aulas anteriores.


